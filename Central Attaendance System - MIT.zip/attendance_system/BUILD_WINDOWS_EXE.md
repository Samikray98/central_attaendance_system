# Building the Windows .exe / Installer

An `.exe` has to be compiled **on a Windows machine** — it can't be cross-built from
another OS. Everything below is already set up in this project so the build itself
only takes two commands.

## Option A: Just a standalone .exe (simplest)

1. Copy this whole `attendance_system` folder onto a Windows PC.
2. Make sure Python 3.9+ is installed (check "Add to PATH" during install).
3. Double-click **`build_exe.bat`** (or run it from Command Prompt).
   - It installs Flask + PyInstaller, then bundles everything into one file.
4. When it finishes, your app is at: `dist\AttendanceSystem.exe`

Double-clicking that file starts the server and opens your browser automatically to
`http://127.0.0.1:5000`. The database file (`attendance.db`) is created next to the
`.exe`, so attendance data is saved between runs. No console/Python needed for the
person running it — it's fully self-contained (~15-20 MB).

## Option B: A proper installer with Start Menu shortcuts (recommended for submission)

1. Do Option A first, so `dist\AttendanceSystem.exe` exists.
2. Install **Inno Setup** (free): https://jrsoftware.org/isdl.php
3. Open `installer.iss` in Inno Setup and click **Build → Compile**
   (or run `iscc installer.iss` from the command line if Inno Setup's compiler is on PATH).
4. Find the result in `installer_output\AttendanceSystem_Setup.exe`

That file is a real Windows installer: it installs to Program Files, adds Start Menu
and optional Desktop shortcuts, and includes an uninstaller — good for a final-year
project demo/submission where you want to hand over something that "installs."

## Notes

- Closing the console window that appears stops the server.
- If Windows SmartScreen warns about an "unrecognized app," that's expected for
  unsigned executables — click "More info → Run anyway." Code signing costs money
  and isn't needed for a college project.
- If you add more students/subjects, that data lives in `attendance.db` next to the
  exe — back it up if you reinstall.
