# Deploying to production

The Flask dev server (`app.run(debug=True)`) is gone from the production
path. It's only used now if you launch `python app.py` directly for local
testing. For anything real, use one of the options below.

## What changed for production readiness

- **Secret key**: set via the `SECRET_KEY` env var (required if `PRODUCTION=true`).
  Generate one: `python -c "import secrets; print(secrets.token_hex(32))"`
- **Database**: SQLite now runs in WAL mode with a busy-timeout, so it
  handles multiple simultaneous users much better than before. Location is
  configurable via `DATABASE_PATH`.
- **Real-time updates**: dashboards now use Server-Sent Events (`/stream`) so
  when a teacher marks attendance, the admin dashboard and student dashboard
  update automatically instead of needing a manual refresh.
  - This uses a simple in-memory broadcaster, which only works correctly with
    **one worker process** (many threads inside that process is fine, and
    required). All the configs below are already set up this way.
  - If you outgrow a single process/server down the line, replace the
    broadcaster in `app.py` with Redis pub/sub - everything else stays the same.

Copy `.env.example` to `.env` and fill it in before using any option below.

---

## Option A: Docker (recommended, works anywhere)

```bash
cp .env.example .env   # edit SECRET_KEY etc.
docker compose up -d --build
```

The app is now on `http://your-server:8000`. Data persists in the
`attendance_data` Docker volume across rebuilds.

To put it behind a real domain with HTTPS, uncomment the `nginx` service in
`docker-compose.yml`, point `nginx.conf`'s `server_name` at your domain, and
get certs (easiest via `certbot --nginx` on the host, or a Certbot container).

## Option B: Linux VPS, no Docker

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # edit values
sudo cp attendance.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now attendance.service
```

Gunicorn is now listening on `127.0.0.1:8000`. Put nginx in front of it using
`nginx.conf` as a starting point (adjust `proxy_pass` to `http://127.0.0.1:8000`
instead of `http://web:8000`), then get a TLS cert with `certbot --nginx`.

## Option C: Windows server (no Docker)

```powershell
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env   REM edit values
waitress-serve --listen=0.0.0.0:8000 wsgi:app
```

Run that last command via NSSM or Task Scheduler so it starts on boot and
restarts if it crashes. Put IIS or nginx-for-Windows in front for TLS if
you need HTTPS.

---

## Quick checklist before going live

- [ ] `SECRET_KEY` set to a real random value, `PRODUCTION=true`
- [ ] Default `admin` / `admin123` and `teacher1` / `teacher123` passwords changed
- [ ] `DATABASE_PATH` points at a location that's actually backed up
- [ ] Running behind HTTPS (nginx/IIS + a real certificate)
- [ ] Only ONE worker process (see real-time note above)
