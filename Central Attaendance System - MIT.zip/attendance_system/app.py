from flask import Flask, render_template, request, redirect, url_for, session, flash, Response
from werkzeug.security import generate_password_hash, check_password_hash
from database import get_db, init_db
import csv
import io
import os
import sys
import json
import queue
import threading
import secrets
import openpyxl
from datetime import date


def resource_path(relative_path):
    """Get the absolute path to a bundled resource, works both for normal
    execution and for a PyInstaller-frozen .exe."""
    if getattr(sys, "frozen", False):
        base_path = sys._MEIPASS
    else:
        base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, relative_path)


app = Flask(
    __name__,
    template_folder=resource_path("templates"),
    static_folder=resource_path("static"),
)

# SECRET_KEY must be set via environment variable in production so sessions
# survive restarts/deploys and aren't signed with a guessable key.
_secret_key = os.environ.get("SECRET_KEY")
if not _secret_key:
    if os.environ.get("FLASK_ENV") == "production" or os.environ.get("PRODUCTION"):
        raise RuntimeError(
            "SECRET_KEY environment variable must be set in production. "
            "Generate one with: python -c \"import secrets; print(secrets.token_hex(32))\""
        )
    _secret_key = secrets.token_hex(32)
    print("WARNING: SECRET_KEY not set - using a random one-off key (dev only).")
app.secret_key = _secret_key

# Initialize the database as soon as the module is imported. Production WSGI
# servers (gunicorn/waitress) import `app` directly and never run the
# `if __name__ == "__main__":` block below, so init needs to happen here.
init_db()


# ---------- Real-time updates (Server-Sent Events) ----------
# Lightweight pub/sub so dashboards refresh instantly when a teacher marks
# attendance, instead of everyone needing to hit F5.
#
# NOTE: this in-memory broadcaster only reaches clients connected to the SAME
# process. Run the production server with ONE worker process and multiple
# threads (see DEPLOYMENT.md) so every connected browser shares one
# broadcaster. If you outgrow a single process, swap this for Redis pub/sub.

_subscribers = []
_subscribers_lock = threading.Lock()


def broadcast_event(event_name, payload):
    message = f"event: {event_name}\ndata: {json.dumps(payload)}\n\n"
    with _subscribers_lock:
        dead = []
        for q in _subscribers:
            try:
                q.put_nowait(message)
            except queue.Full:
                dead.append(q)
        for q in dead:
            _subscribers.remove(q)


@app.route("/stream")
def stream():
    if "user_id" not in session:
        return Response(status=401)

    client_queue = queue.Queue(maxsize=20)
    with _subscribers_lock:
        _subscribers.append(client_queue)

    def gen():
        try:
            yield ": connected\n\n"
            while True:
                yield client_queue.get()
        except GeneratorExit:
            pass
        finally:
            with _subscribers_lock:
                if client_queue in _subscribers:
                    _subscribers.remove(client_queue)

    return Response(gen(), mimetype="text/event-stream", headers={
        "Cache-Control": "no-cache",
        "X-Accel-Buffering": "no",  # disable nginx buffering for SSE
    })


# ---------- Helpers ----------

def login_required(role=None):
    allowed = (role,) if isinstance(role, str) else role

    def wrapper(f):
        def decorated(*args, **kwargs):
            if "user_id" not in session:
                flash("Please log in first.", "error")
                return redirect(url_for("login"))
            if allowed and session.get("role") not in allowed:
                flash("You don't have access to that page.", "error")
                return redirect(url_for("login"))
            return f(*args, **kwargs)
        decorated.__name__ = f.__name__
        return decorated
    return wrapper


# ---------- Auth ----------

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"].strip()
        password = request.form["password"]

        db = get_db()
        user = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        db.close()

        if user and check_password_hash(user["password_hash"], password):
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["role"] = user["role"]
            session["student_id"] = user["student_id"]

            if user["role"] == "admin":
                return redirect(url_for("admin_dashboard"))
            elif user["role"] == "teacher":
                return redirect(url_for("teacher_dashboard"))
            else:
                return redirect(url_for("student_dashboard"))
        else:
            flash("Invalid username or password.", "error")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ---------- Admin ----------

@app.route("/admin/dashboard")
@login_required(role="admin")
def admin_dashboard():
    db = get_db()
    student_count = db.execute("SELECT COUNT(*) c FROM students").fetchone()["c"]
    subject_count = db.execute("SELECT COUNT(*) c FROM subjects").fetchone()["c"]
    teacher_count = db.execute("SELECT COUNT(*) c FROM users WHERE role='teacher'").fetchone()["c"]

    dept_rows = db.execute(
        """
        SELECT
            COALESCE(NULLIF(TRIM(s.department), ''), 'Unassigned') AS department,
            COUNT(a.id) AS total,
            SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS present
        FROM students s
        LEFT JOIN attendance a ON a.student_id = s.id
        GROUP BY department
        ORDER BY department
        """
    ).fetchall()

    dept_attendance = []
    for r in dept_rows:
        total = r["total"] or 0
        present = r["present"] or 0
        pct = round((present / total) * 100, 1) if total > 0 else 0.0
        dept_attendance.append(
            {"department": r["department"], "total": total, "present": present, "percentage": pct}
        )

    db.close()
    return render_template(
        "admin_dashboard.html",
        student_count=student_count,
        subject_count=subject_count,
        teacher_count=teacher_count,
        dept_attendance=dept_attendance,
    )


@app.route("/admin/students", methods=["GET", "POST"])
@login_required(role="admin")
def admin_students():
    db = get_db()

    if request.method == "POST":
        name = request.form["name"].strip()
        roll_no = request.form["roll_no"].strip()
        class_name = request.form["class_name"].strip()
        department = request.form.get("department", "").strip()

        try:
            cur = db.execute(
                "INSERT INTO students (name, roll_no, class_name, department) VALUES (?, ?, ?, ?)",
                (name, roll_no, class_name, department or None),
            )
            student_id = cur.lastrowid
            # Auto-create a login for the student: username = roll number, password = roll number
            db.execute(
                "INSERT INTO users (username, password_hash, role, student_id) VALUES (?, ?, 'student', ?)",
                (roll_no, generate_password_hash(roll_no), student_id),
            )
            db.commit()
            flash(f"Student added. Login username/password: {roll_no}", "success")
        except db.IntegrityError:
            flash("Roll number already exists.", "error")

    dept_filter = request.args.get("department", "")
    if dept_filter:
        students = db.execute(
            "SELECT * FROM students WHERE department = ? ORDER BY class_name, roll_no", (dept_filter,)
        ).fetchall()
    else:
        students = db.execute("SELECT * FROM students ORDER BY department, class_name, roll_no").fetchall()
    db.close()
    return render_template("admin_students.html", students=students, dept_filter=dept_filter)


@app.route("/admin/students/bulk_upload", methods=["POST"])
@login_required(role="admin")
def bulk_upload_students():
    file = request.files.get("excel_file")
    department = request.form.get("bulk_department", "").strip()

    if not file or file.filename == "":
        flash("Please choose an Excel file to upload.", "error")
        return redirect(url_for("admin_students"))

    if not file.filename.lower().endswith((".xlsx", ".xls")):
        flash("Only .xlsx or .xls files are supported.", "error")
        return redirect(url_for("admin_students"))

    try:
        wb = openpyxl.load_workbook(file, data_only=True)
        ws = wb.active
    except Exception:
        flash("Could not read that Excel file. Please check the format.", "error")
        return redirect(url_for("admin_students"))

    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        flash("The uploaded sheet is empty.", "error")
        return redirect(url_for("admin_students"))

    # Detect header row (Name / Roll No / Class, any casing/order) and map columns
    header = [str(c).strip().lower() if c is not None else "" for c in rows[0]]
    col_index = {}
    for i, h in enumerate(header):
        if h in ("name", "student name", "full name"):
            col_index["name"] = i
        elif h in ("roll no", "roll_no", "roll number", "rollno"):
            col_index["roll_no"] = i
        elif h in ("class", "class_name", "class name", "section"):
            col_index["class_name"] = i
        elif h in ("department", "dept", "stream"):
            col_index["department"] = i

    data_rows = rows[1:] if col_index else rows
    if "name" not in col_index or "roll_no" not in col_index:
        flash(
            "Sheet must have 'Name' and 'Roll No' columns (Class and Department are optional).",
            "error",
        )
        return redirect(url_for("admin_students"))

    db = get_db()
    added, skipped = 0, 0
    for row in data_rows:
        if row is None or all(c is None for c in row):
            continue
        try:
            name = str(row[col_index["name"]]).strip() if row[col_index["name"]] is not None else ""
            roll_no = str(row[col_index["roll_no"]]).strip() if row[col_index["roll_no"]] is not None else ""
        except IndexError:
            continue
        if not name or not roll_no:
            skipped += 1
            continue

        class_name = ""
        if "class_name" in col_index and col_index["class_name"] < len(row) and row[col_index["class_name"]] is not None:
            class_name = str(row[col_index["class_name"]]).strip()

        row_department = department
        if "department" in col_index and col_index["department"] < len(row) and row[col_index["department"]] is not None:
            sheet_dept = str(row[col_index["department"]]).strip()
            if sheet_dept:
                row_department = sheet_dept

        try:
            cur = db.execute(
                "INSERT INTO students (name, roll_no, class_name, department) VALUES (?, ?, ?, ?)",
                (name, roll_no, class_name, row_department or None),
            )
            student_id = cur.lastrowid
            db.execute(
                "INSERT INTO users (username, password_hash, role, student_id) VALUES (?, ?, 'student', ?)",
                (roll_no, generate_password_hash(roll_no), student_id),
            )
            added += 1
        except db.IntegrityError:
            skipped += 1

    db.commit()
    db.close()

    msg = f"{added} student(s) added."
    if skipped:
        msg += f" {skipped} row(s) skipped (missing data or duplicate roll number)."
    flash(msg, "success" if added else "error")
    return redirect(url_for("admin_students"))


@app.route("/admin/students/template")
@login_required(role="admin")
def download_student_template():
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Students"
    ws.append(["Name", "Roll No", "Class", "Department"])
    ws.append(["Rahul Mondal", "24CSE001", "CSE-A 2nd Year", "CSE"])
    ws.append(["Ananya Das", "24ECE014", "ECE-B 1st Year", "ECE"])

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return Response(
        buf.read(),
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment;filename=student_upload_template.xlsx"},
    )


@app.route("/admin/students/delete/<int:student_id>")
@login_required(role="admin")
def delete_student(student_id):
    db = get_db()
    db.execute("DELETE FROM attendance WHERE student_id = ?", (student_id,))
    db.execute("DELETE FROM users WHERE student_id = ?", (student_id,))
    db.execute("DELETE FROM students WHERE id = ?", (student_id,))
    db.commit()
    db.close()
    flash("Student removed.", "success")
    return redirect(url_for("admin_students"))


@app.route("/admin/subjects", methods=["GET", "POST"])
@login_required(role="admin")
def admin_subjects():
    db = get_db()
    if request.method == "POST":
        name = request.form["name"].strip()
        stream = request.form.get("stream", "").strip()
        year = request.form.get("year", "").strip()
        try:
            db.execute(
                "INSERT INTO subjects (name, stream, year) VALUES (?, ?, ?)",
                (name, stream or None, year or None),
            )
            db.commit()
            flash("Subject added.", "success")
        except db.IntegrityError:
            flash("This subject already exists for that stream/year.", "error")
    subjects = db.execute(
        "SELECT * FROM subjects ORDER BY stream, year, name"
    ).fetchall()
    db.close()
    return render_template("admin_subjects.html", subjects=subjects)


@app.route("/admin/subjects/delete/<int:subject_id>")
@login_required(role="admin")
def delete_subject(subject_id):
    db = get_db()
    db.execute("DELETE FROM subjects WHERE id=?", (subject_id,))
    db.commit()
    db.close()
    flash("Subject removed.", "success")
    return redirect(url_for("admin_subjects"))


@app.route("/admin/users", methods=["GET", "POST"])
@login_required(role="admin")
def admin_users():
    db = get_db()
    if request.method == "POST":
        username = request.form["username"].strip()
        password = request.form["password"].strip()
        role = request.form.get("role", "teacher").strip()
        department = request.form.get("department", "").strip()

        if role not in ("admin", "teacher"):
            flash("Invalid role selected.", "error")
        else:
            try:
                db.execute(
                    "INSERT INTO users (username, password_hash, role, department) VALUES (?, ?, ?, ?)",
                    (username, generate_password_hash(password), role, department or None),
                )
                db.commit()
                flash(f"{role.capitalize()} account created.", "success")
            except db.IntegrityError:
                flash("Username already exists.", "error")

    users = db.execute(
        "SELECT * FROM users WHERE role IN ('admin','teacher') ORDER BY role, username"
    ).fetchall()
    db.close()
    return render_template("admin_users.html", users=users)


@app.route("/admin/users/delete/<int:user_id>")
@login_required(role="admin")
def delete_user(user_id):
    if user_id == session.get("user_id"):
        flash("You can't remove your own account while logged in.", "error")
        return redirect(url_for("admin_users"))

    db = get_db()
    db.execute("DELETE FROM users WHERE id=? AND role IN ('admin','teacher')", (user_id,))
    db.commit()
    db.close()
    flash("User removed.", "success")
    return redirect(url_for("admin_users"))


@app.route("/admin/reports", methods=["GET", "POST"])
@login_required(role="admin")
def admin_reports():
    db = get_db()
    subjects = db.execute("SELECT * FROM subjects ORDER BY name").fetchall()
    classes = db.execute("SELECT DISTINCT class_name FROM students ORDER BY class_name").fetchall()

    report = None
    selected_class = None
    selected_subject = None

    if request.method == "POST":
        selected_class = request.form.get("class_name")
        selected_subject = request.form.get("subject_id")

        students = db.execute(
            "SELECT * FROM students WHERE class_name = ? ORDER BY roll_no", (selected_class,)
        ).fetchall()

        # One aggregate query for the whole class instead of two queries
        # per student (that N+1 pattern is what made this page slow).
        stats_rows = db.execute(
            """SELECT student_id,
                      COUNT(*) AS total,
                      SUM(CASE WHEN status='Present' THEN 1 ELSE 0 END) AS present
               FROM attendance
               WHERE subject_id = ?
               GROUP BY student_id""",
            (selected_subject,),
        ).fetchall()
        stats_by_student = {r["student_id"]: r for r in stats_rows}

        report = []
        for s in students:
            st = stats_by_student.get(s["id"])
            total = st["total"] if st else 0
            present = st["present"] if st else 0
            pct = round((present / total) * 100, 1) if total > 0 else 0.0
            report.append({
                "roll_no": s["roll_no"],
                "name": s["name"],
                "total": total,
                "present": present,
                "percentage": pct,
            })

    db.close()
    return render_template(
        "admin_reports.html",
        subjects=subjects,
        classes=classes,
        report=report,
        selected_class=selected_class,
        selected_subject=selected_subject,
    )


@app.route("/admin/reports/export")
@login_required(role="admin")
def export_report():
    class_name = request.args.get("class_name")
    subject_id = request.args.get("subject_id")

    db = get_db()
    students = db.execute(
        "SELECT * FROM students WHERE class_name = ? ORDER BY roll_no", (class_name,)
    ).fetchall()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Mallabhum Institute of Technology"])
    writer.writerow(["Braja Radhanagar, P.O. Gossaipur, P.S. Bishnupur, Pin - 722122"])
    writer.writerow([f"Attendance Report - Class: {class_name}"])
    writer.writerow([])
    writer.writerow(["Roll No", "Name", "Total Classes", "Present", "Percentage"])

    stats_rows = db.execute(
        """SELECT student_id,
                  COUNT(*) AS total,
                  SUM(CASE WHEN status='Present' THEN 1 ELSE 0 END) AS present
           FROM attendance
           WHERE subject_id = ?
           GROUP BY student_id""",
        (subject_id,),
    ).fetchall()
    stats_by_student = {r["student_id"]: r for r in stats_rows}

    for s in students:
        st = stats_by_student.get(s["id"])
        total = st["total"] if st else 0
        present = st["present"] if st else 0
        pct = round((present / total) * 100, 1) if total > 0 else 0.0
        writer.writerow([s["roll_no"], s["name"], total, present, pct])

    db.close()
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment;filename=attendance_report_{class_name}.csv"},
    )


# ---------- Teacher ----------

@app.route("/teacher/dashboard")
@login_required(role="teacher")
def teacher_dashboard():
    return render_template("teacher_dashboard.html")


@app.route("/teacher/attendance-register", methods=["GET", "POST"])
@login_required(role=("admin", "teacher"))
def attendance_register():
    db = get_db()
    subjects_all = db.execute("SELECT * FROM subjects ORDER BY name").fetchall()
    departments = [r["department"] for r in db.execute(
        "SELECT DISTINCT department FROM students WHERE department IS NOT NULL AND department != '' ORDER BY department"
    ).fetchall()]
    years = ["1st Year", "2nd Year", "3rd Year", "4th Year"]

    students = []
    selected_department = request.values.get("department")
    selected_year = request.values.get("year")
    selected_subject = request.values.get("subject_id")
    selected_date = request.values.get("date_val", date.today().isoformat())

    # Only offer subjects matching the chosen year, once one is picked.
    if selected_year:
        subjects = [s for s in subjects_all if s["year"] == selected_year]
    else:
        subjects = subjects_all

    if request.method == "POST" and "mark_submit" in request.form:
        marked_at = __import__("datetime").datetime.now().isoformat(sep=" ", timespec="seconds")
        for key, value in request.form.items():
            if key.startswith("status_"):
                student_id = key.replace("status_", "")
                db.execute(
                    """INSERT INTO attendance (student_id, subject_id, date, status, marked_by, marked_at)
                       VALUES (?, ?, ?, ?, ?, ?)
                       ON CONFLICT(student_id, subject_id, date)
                       DO UPDATE SET status = excluded.status,
                                     marked_by = excluded.marked_by,
                                     marked_at = excluded.marked_at""",
                    (student_id, selected_subject, selected_date, value, session["username"], marked_at),
                )
        db.commit()
        flash("Attendance saved.", "success")
        broadcast_event("attendance", {
            "department": selected_department,
            "year": selected_year,
            "subject_id": selected_subject,
            "date": selected_date,
            "marked_by": session.get("username"),
            "marked_at": marked_at,
        })

    if selected_department and selected_subject:
        students = db.execute(
            "SELECT * FROM students WHERE department = ? ORDER BY roll_no", (selected_department,)
        ).fetchall()

        # Pre-fill existing statuses for this date/subject if already marked
        existing = {}
        rows = db.execute(
            "SELECT student_id, status FROM attendance WHERE subject_id=? AND date=?",
            (selected_subject, selected_date),
        ).fetchall()
        existing = {r["student_id"]: r["status"] for r in rows}
        students = [dict(s, existing_status=existing.get(s["id"], "Present")) for s in students]

    subject_obj = None
    if selected_subject:
        subject_obj = db.execute("SELECT * FROM subjects WHERE id = ?", (selected_subject,)).fetchone()

    present_count = sum(1 for s in students if s["existing_status"] == "Present")
    total_count = len(students)
    absent_count = total_count - present_count

    db.close()
    return render_template(
        "attendance_register.html",
        subjects=subjects,
        departments=departments,
        years=years,
        students=students,
        subject_obj=subject_obj,
        total_count=total_count,
        present_count=present_count,
        absent_count=absent_count,
        selected_department=selected_department,
        selected_year=selected_year,
        selected_subject=selected_subject,
        selected_date=selected_date,
    )


@app.route("/attendance/department", methods=["GET"])
@login_required(role=("admin", "teacher"))
def department_attendance():
    db = get_db()
    departments = [r["department"] for r in db.execute(
        "SELECT DISTINCT department FROM students WHERE department IS NOT NULL AND department != '' ORDER BY department"
    ).fetchall()]
    subjects = db.execute("SELECT * FROM subjects ORDER BY name").fetchall()
    years = [r["year"] for r in db.execute(
        "SELECT DISTINCT year FROM subjects WHERE year IS NOT NULL AND year != '' ORDER BY year"
    ).fetchall()]

    selected_department = request.args.get("department")
    selected_year = request.args.get("year")
    selected_subject = request.args.get("subject_id")
    selected_date = request.args.get("date_val")

    records = []
    if selected_department:
        query = """
            SELECT s.name AS student_name, s.roll_no, s.department, s.class_name,
                   subj.name AS subject_name, subj.year AS subject_year,
                   a.date, a.marked_at, a.status, a.marked_by
            FROM attendance a
            JOIN students s ON s.id = a.student_id
            JOIN subjects subj ON subj.id = a.subject_id
            WHERE s.department = ?
        """
        params = [selected_department]
        if selected_year:
            query += " AND subj.year = ?"
            params.append(selected_year)
        if selected_subject:
            query += " AND subj.id = ?"
            params.append(selected_subject)
        if selected_date:
            query += " AND a.date = ?"
            params.append(selected_date)
        query += " ORDER BY a.marked_at DESC, s.roll_no"
        records = db.execute(query, params).fetchall()

    db.close()
    return render_template(
        "department_attendance.html",
        departments=departments,
        subjects=subjects,
        years=years,
        records=records,
        selected_department=selected_department,
        selected_year=selected_year,
        selected_subject=selected_subject,
        selected_date=selected_date,
    )


# ---------- Student ----------

@app.route("/student/dashboard")
@login_required(role="student")
def student_dashboard():
    db = get_db()
    student_id = session.get("student_id")
    student = db.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
    subjects = db.execute("SELECT * FROM subjects ORDER BY name").fetchall()

    summary = []
    for subj in subjects:
        total = db.execute(
            "SELECT COUNT(*) c FROM attendance WHERE student_id=? AND subject_id=?",
            (student_id, subj["id"]),
        ).fetchone()["c"]
        present = db.execute(
            "SELECT COUNT(*) c FROM attendance WHERE student_id=? AND subject_id=? AND status='Present'",
            (student_id, subj["id"]),
        ).fetchone()["c"]
        pct = round((present / total) * 100, 1) if total > 0 else 0.0
        summary.append({"subject": subj["name"], "total": total, "present": present, "percentage": pct})

    db.close()
    return render_template("student_dashboard.html", student=student, summary=summary)


if __name__ == "__main__":
    # This block only runs when launching directly with `python app.py`
    # (e.g. the desktop/Windows .exe build). For production deployments,
    # do NOT use this - run via gunicorn/waitress instead. See DEPLOYMENT.md.
    debug_mode = os.environ.get("FLASK_DEBUG", "false").lower() == "true"
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "5000"))
    app.run(host=host, port=port, debug=debug_mode)
