; Inno Setup script — creates a proper "Setup.exe" installer for the app.
; 1. Install Inno Setup (free): https://jrsoftware.org/isdl.php
; 2. First build AttendanceSystem.exe using build_exe.bat (creates dist\AttendanceSystem.exe)
; 3. Open this file in Inno Setup and click Build > Compile
;    (or run: iscc installer.iss  from the command line)
; The final installer will appear in the "installer_output" folder.

[Setup]
AppName=Student Attendance System
AppVersion=1.0
DefaultDirName={autopf}\StudentAttendanceSystem
DefaultGroupName=Student Attendance System
UninstallDisplayIcon={app}\AttendanceSystem.exe
OutputDir=installer_output
OutputBaseFilename=AttendanceSystem_Setup
Compression=lzma
SolidCompression=yes
ArchitecturesInstallIn64BitMode=x64compatible

[Files]
Source: "dist\AttendanceSystem.exe"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\Student Attendance System"; Filename: "{app}\AttendanceSystem.exe"
Name: "{group}\Uninstall Student Attendance System"; Filename: "{uninstallexe}"
Name: "{autodesktop}\Student Attendance System"; Filename: "{app}\AttendanceSystem.exe"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"

[Run]
Filename: "{app}\AttendanceSystem.exe"; Description: "Launch Student Attendance System now"; Flags: nowait postinstall skipifsilent
