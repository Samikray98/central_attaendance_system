@echo off
REM Run this on a Windows machine with Python installed.
REM It installs the build tool and packages the app into a single .exe

echo Installing dependencies...
pip install -r requirements.txt
pip install pyinstaller

echo.
echo Building AttendanceSystem.exe ...
pyinstaller --noconfirm --onefile --name "AttendanceSystem" ^
    --add-data "templates;templates" ^
    --add-data "static;static" ^
    desktop_launcher.py

echo.
echo Done! Find your exe inside the "dist" folder: dist\AttendanceSystem.exe
pause
