# Student Attendance Management System
### Mallabhum Institute of Technology
Braja Radhanagar, P.O. Gossaipur, P.S. Bishnupur, Pin - 722122

A web-based attendance system built with **Flask** (Python) and **SQLite**, designed as a
final-year CSE B.Tech project. Supports three roles: Admin, Teacher, and Student.

## Features

- **Admin**
  - Add/remove students (auto-creates a student login: username & password = roll number)
  - Bulk-upload students from an Excel sheet (.xlsx/.xls), department-wise, with a downloadable template
  - Add subjects
  - Create login accounts for staff, choosing a role (Teacher or Admin) and department
  - View class-wise / subject-wise attendance reports
  - Export reports to CSV
- **Teacher**
  - Select class, subject, and date
  - Mark each student Present/Absent
  - Attendance can be edited later (updates existing record instead of duplicating)
- **Student**
  - Log in and view attendance percentage per subject
  - Rows below 75% are highlighted in red

## Tech Stack

- Python 3, Flask
- SQLite (no external DB server needed)
- Jinja2 templates, plain HTML/CSS (no JS framework needed)
- Passwords hashed with Werkzeug's `generate_password_hash`

## Setup Instructions

1. Install Python 3.9+ if not already installed.
2. Open a terminal in this folder and install dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Run the app:
   ```
   python app.py
   ```
4. Open your browser at: `http://127.0.0.1:5000`

The database (`attendance.db`) and default accounts are created automatically the first
time you run the app.

## Default Login Accounts

| Role    | Username | Password   |
|---------|----------|------------|
| Admin   | admin    | admin123   |
| Teacher | teacher1 | teacher123 |

Student accounts are created automatically when the admin adds a student
(username = roll number, password = roll number). Students should be told to change
their password in a real deployment — this demo keeps it simple for evaluation purposes.

## Suggested Demo Flow (for viva/presentation)

1. Log in as **admin** → add a subject, add 3-4 students, create a teacher account (Manage Users → pick role & department).
2. Log out, log in as **teacher1** → select the class/subject/today's date → mark
   attendance for the students.
3. Log out, log in as one of the **students** (username/password = their roll number)
   → show their attendance percentage.
4. Log back in as admin → go to Reports → view/export the class report as CSV.

## Possible Extensions (mention these if asked "future scope")

- QR code / barcode based attendance marking
- Face recognition for automatic attendance
- Email/SMS alerts when attendance drops below 75%
- REST API + mobile app frontend
- Role-based analytics dashboard with charts

## Project Structure

```
attendance_system/
├── app.py              # Flask routes and logic
├── database.py         # DB schema + seed data
├── requirements.txt
├── templates/           # HTML pages
└── static/style.css     # Styling
```
