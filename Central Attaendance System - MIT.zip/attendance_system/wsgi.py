"""
Production entrypoint.

Gunicorn (Linux/macOS):
    gunicorn wsgi:app --workers 1 --threads 8 --bind 0.0.0.0:8000

Waitress (Windows):
    waitress-serve --listen=0.0.0.0:8000 wsgi:app

Only run with 1 worker process. The real-time attendance updates (SSE) use
an in-memory broadcaster that lives inside a single process - multiple
gunicorn *workers* would each keep their own separate list of connected
browsers, so a browser talking to worker A would never see an update
saved via worker B. Multiple *threads* within that one worker are fine
(and required, so one open /stream connection doesn't block everyone else).
"""

from app import app  # noqa: F401
