import sqlite3
import os
import sys
from werkzeug.security import generate_password_hash


def get_data_dir():
    """Folder where the database should live: next to the .exe when frozen
    by PyInstaller, or next to this script when run normally."""
    if getattr(sys, "frozen", False):
        base = os.path.dirname(sys.executable)
    else:
        base = os.path.dirname(os.path.abspath(__file__))
    return base


DB_NAME = os.environ.get("DATABASE_PATH") or os.path.join(get_data_dir(), "attendance.db")


def get_db():
    conn = sqlite3.connect(DB_NAME, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    # WAL mode lets readers and a writer work concurrently instead of
    # locking the whole database file - important once this is served to
    # multiple users at once instead of a single desktop user.
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 10000")
    return conn


def init_db():
    conn = get_db()
    cur = conn.cursor()

    cur.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('admin','teacher','student')),
        department TEXT,
        student_id INTEGER,
        FOREIGN KEY(student_id) REFERENCES students(id)
    );

    CREATE TABLE IF NOT EXISTS students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        roll_no TEXT UNIQUE NOT NULL,
        class_name TEXT NOT NULL,
        department TEXT
    );

    CREATE TABLE IF NOT EXISTS subjects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        stream TEXT,
        year TEXT,
        UNIQUE(name, stream, year)
    );

    CREATE TABLE IF NOT EXISTS attendance (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        subject_id INTEGER NOT NULL,
        date TEXT NOT NULL,
        status TEXT NOT NULL CHECK(status IN ('Present','Absent')),
        marked_by TEXT,
        UNIQUE(student_id, subject_id, date),
        FOREIGN KEY(student_id) REFERENCES students(id),
        FOREIGN KEY(subject_id) REFERENCES subjects(id)
    );
    """)

    # Migration: older databases may have a subjects table without stream/year
    existing_cols = [row["name"] for row in cur.execute("PRAGMA table_info(subjects)").fetchall()]
    if "stream" not in existing_cols:
        cur.execute("ALTER TABLE subjects ADD COLUMN stream TEXT")
    if "year" not in existing_cols:
        cur.execute("ALTER TABLE subjects ADD COLUMN year TEXT")

    existing_user_cols = [row["name"] for row in cur.execute("PRAGMA table_info(users)").fetchall()]
    if "department" not in existing_user_cols:
        cur.execute("ALTER TABLE users ADD COLUMN department TEXT")

    existing_student_cols = [row["name"] for row in cur.execute("PRAGMA table_info(students)").fetchall()]
    if "department" not in existing_student_cols:
        cur.execute("ALTER TABLE students ADD COLUMN department TEXT")

    existing_attendance_cols = [row["name"] for row in cur.execute("PRAGMA table_info(attendance)").fetchall()]
    if "marked_at" not in existing_attendance_cols:
        cur.execute("ALTER TABLE attendance ADD COLUMN marked_at TEXT")

    # Indexes: the attendance table is filtered/joined constantly by
    # subject+date (attendance register), student+subject (reports), and
    # date alone. Without these, every filter does a full table scan and
    # gets slower as attendance history grows. students/subjects are
    # filtered by department/class/year just as often.
    cur.executescript("""
    CREATE INDEX IF NOT EXISTS idx_attendance_subject_date ON attendance(subject_id, date);
    CREATE INDEX IF NOT EXISTS idx_attendance_student_subject ON attendance(student_id, subject_id);
    CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(date);
    CREATE INDEX IF NOT EXISTS idx_students_department ON students(department);
    CREATE INDEX IF NOT EXISTS idx_students_class_name ON students(class_name);
    CREATE INDEX IF NOT EXISTS idx_subjects_year ON subjects(year);
    """)

    # Seed default admin
    cur.execute("SELECT * FROM users WHERE username = 'admin'")
    if not cur.fetchone():
        cur.execute(
            "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
            ("admin", generate_password_hash("admin123"), "admin"),
        )

    # Seed a sample teacher
    cur.execute("SELECT * FROM users WHERE username = 'teacher1'")
    if not cur.fetchone():
        cur.execute(
            "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
            ("teacher1", generate_password_hash("teacher123"), "teacher"),
        )

    conn.commit()
    conn.close()
    print("Database initialized: attendance.db")


if __name__ == "__main__":
    init_db()
