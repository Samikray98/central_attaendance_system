"""
Entry point used to build the Windows .exe.
Starts the Flask server in the background and opens the default browser,
so the app feels like a normal desktop program instead of a command-line tool.
"""

import threading
import webbrowser
import time
import sys
import os

from app import app
from database import init_db

HOST = "127.0.0.1"
PORT = 5000


def open_browser():
    time.sleep(1.2)  # give the server a moment to start
    webbrowser.open(f"http://{HOST}:{PORT}")


def main():
    init_db()
    threading.Thread(target=open_browser, daemon=True).start()

    print("=" * 50)
    print(" Student Attendance Management System")
    print(f" Running at http://{HOST}:{PORT}")
    print(" Close this window to stop the server.")
    print("=" * 50)

    app.run(host=HOST, port=PORT, debug=False, use_reloader=False)


if __name__ == "__main__":
    main()
